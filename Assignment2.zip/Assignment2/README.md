# Seg3103_playground
Riley de Domenico - 300016694
To run code coverage test use mix test --cover under Assignment2/grades/grades in cmd 

Further: pdf Homework2 is the answers to the questions in text including documentation