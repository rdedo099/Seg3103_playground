# Changelog

## v1.6.0

  * Deprecate MIME.valid?
  * Ignore media type params
  * Detect subtype suffix according to the spec

## v1.5.0

  * Compare extensions in a case-insensitive way (see
    [elixir-plug/mime#38](https://github.com/elixir-plug/mime/issues/38)).
