defmodule GradesWeb.LayoutView do
  use GradesWeb, :view
end
