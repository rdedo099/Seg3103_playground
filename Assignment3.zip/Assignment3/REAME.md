Steps to run once maven is installed correctly:
Step 1: compile maven with: mvn compile
Step 2: run the file with: mvn package -DskipTests
Step 3: Create the local server with: java -jar bookstore5.jar
Step 4: run the tests with: mvn test
